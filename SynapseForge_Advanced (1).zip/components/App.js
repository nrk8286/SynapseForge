
import React from 'react';

function App() {
    return (
        <div>
            <h1>Welcome to SynapseForge</h1>
            <p>AI-Powered Social Media Platform</p>
        </div>
    );
}

export default App;
