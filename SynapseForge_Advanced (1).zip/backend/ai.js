
const express = require('express');
const router = express.Router();

router.post('/generate', (req, res) => {
    const { prompt } = req.body;
    // Simulated response
    res.json({ output: `Simulated AI output for: ${prompt}` });
});

module.exports = router;
