
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const users = [{ id: 1, username: "user1", password: "pass1" }];

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        const token = jwt.sign({ userId: user.id }, 'secret_key', { expiresIn: '1h' });
        res.json({ token });
    } else {
        res.status(401).json({ message: "Invalid credentials" });
    }
});

router.post('/register', (req, res) => {
    const { username, password } = req.body;
    const user = { id: users.length + 1, username, password };
    users.push(user);
    res.status(201).json({ message: "User registered" });
});

module.exports = router;
