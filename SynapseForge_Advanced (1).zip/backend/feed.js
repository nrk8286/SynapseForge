
const express = require('express');
const router = express.Router();

const posts = [
    { id: 1, content: "First post", timestamp: Date.now() - 10000 },
    { id: 2, content: "Another post", timestamp: Date.now() - 5000 }
];

router.get('/', (req, res) => {
    const sortedPosts = posts.sort((a, b) => b.timestamp - a.timestamp);
    res.json(sortedPosts);
});

module.exports = router;
