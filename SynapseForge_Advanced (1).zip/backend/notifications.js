
const express = require('express');
const router = express.Router();

const notifications = [
    { userId: 1, message: "Welcome to SynapseForge!" }
];

router.get('/:userId', (req, res) => {
    const userId = parseInt(req.params.userId);
    const userNotifications = notifications.filter(n => n.userId === userId);
    res.json(userNotifications);
});

module.exports = router;
