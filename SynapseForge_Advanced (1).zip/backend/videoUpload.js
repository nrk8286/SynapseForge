
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const router = express.Router();

const upload = multer({ dest: 'uploads/' });

router.post('/upload', upload.single('video'), (req, res) => {
    const tempPath = req.file.path;
    const targetPath = path.join(__dirname, `../uploads/${req.file.originalname}`);

    fs.rename(tempPath, targetPath, err => {
        if (err) return res.sendStatus(500);
        res.status(200).send("Video uploaded!");
    });
});

module.exports = router;
