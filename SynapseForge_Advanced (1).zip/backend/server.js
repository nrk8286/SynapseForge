
const express = require('express');
const http = require('http');
const cors = require('cors');
const app = express();
const server = http.createServer(app);
const setupSocket = require('./socket');
const aiRouter = require('./ai');
const videoRouter = require('./videoUpload');
const authRouter = require('./auth');
const notifRouter = require('./notifications');
const feedRouter = require('./feed');

app.use(cors());
app.use(express.json());

app.use('/api/ai', aiRouter);
app.use('/api/video', videoRouter);
app.use('/api/auth', authRouter);
app.use('/api/notifications', notifRouter);
app.use('/api/feed', feedRouter);

setupSocket(server);

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
